<?php 
$server = "localhost"; 
$user = "root"; // Se agregó el punto y coma que faltaba
$pass = ""; 
$bd = "DianitasDB"; 

$cx = mysqli_connect($server, $user, $pass, $bd); 

?>
